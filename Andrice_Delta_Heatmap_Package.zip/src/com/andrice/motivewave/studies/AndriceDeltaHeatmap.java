package com.andrice.motivewave.studies;

import java.awt.Color;

import com.motivewave.platform.sdk.common.DataContext;
import com.motivewave.platform.sdk.common.DataSeries;
import com.motivewave.platform.sdk.common.Defaults;
import com.motivewave.platform.sdk.common.Instrument;
import com.motivewave.platform.sdk.common.desc.ColorDescriptor;
import com.motivewave.platform.sdk.common.desc.DoubleDescriptor;
import com.motivewave.platform.sdk.common.desc.ValueDescriptor;
import com.motivewave.platform.sdk.study.Study;
import com.motivewave.platform.sdk.study.StudyHeader;

/**
 * Colors the chart's native price bars from true bid/ask trade delta.
 *
 * Delta      = volume traded at ask - volume traded at bid
 * Delta pct  = delta / total classified trade volume * 100
 *
 * This study intentionally does not synthesize delta from OHLC bars. Accurate
 * historical output therefore requires bid/ask-classified historical ticks.
 */
@StudyHeader(
    namespace = "com.andrice.motivewave",
    id = "ANDRICE_DELTA_HEATMAP_V1",
    name = "Andrice Delta Heatmap",
    label = "Delta Heatmap",
    desc = "Colors price candles by bid/ask trade-delta intensity.",
    menu = "Andrice Indicators",
    overlay = true,
    requiresVolume = true,
    requiresBidAskHistory = true,
    supportsBarUpdates = true,
    requiresBarUpdates = true,
    barUpdatesByDefault = true,
    allowTickAggregate = true,
    allowTickFilter = true)
public class AndriceDeltaHeatmap extends Study {

  private static final String NEUTRAL_ZONE = "neutralZone";
  private static final String FULL_INTENSITY = "fullIntensity";
  private static final String MIN_TRADE_SIZE = "minTradeSize";
  private static final String POSITIVE_COLOR = "positiveColor";
  private static final String NEGATIVE_COLOR = "negativeColor";
  private static final String NEUTRAL_COLOR = "neutralColor";

  private static final Color DEFAULT_POSITIVE = new Color(26, 158, 218);
  private static final Color DEFAULT_NEGATIVE = new Color(222, 62, 52);
  private static final Color DEFAULT_NEUTRAL = new Color(116, 125, 133);

  private enum Values {
    ASK_VOLUME,
    BID_VOLUME,
    TOTAL_VOLUME,
    DELTA,
    DELTA_PERCENT
  }

  @Override
  public void initialize(Defaults defaults) {
    var sd = createSD();
    var tab = sd.addTab("General");

    var calculation = tab.addGroup("Delta Calculation");
    calculation.addRow(new DoubleDescriptor(
        NEUTRAL_ZONE, "Neutral Zone (%)", 10.0, 0.0, 50.0, 1.0));
    calculation.addRow(new DoubleDescriptor(
        FULL_INTENSITY, "Full Color At (%)", 60.0, 1.0, 100.0, 1.0));
    calculation.addRow(new DoubleDescriptor(
        MIN_TRADE_SIZE, "Minimum Trade Size", 0.0, 0.0, 1000000.0, 1.0));

    var colors = tab.addGroup("Heatmap Colors");
    colors.addRow(new ColorDescriptor(POSITIVE_COLOR, "Positive Delta", DEFAULT_POSITIVE));
    colors.addRow(new ColorDescriptor(NEGATIVE_COLOR, "Negative Delta", DEFAULT_NEGATIVE));
    colors.addRow(new ColorDescriptor(NEUTRAL_COLOR, "Neutral", DEFAULT_NEUTRAL));

    var rd = createRD();
    rd.setLabelSettings(NEUTRAL_ZONE, FULL_INTENSITY, MIN_TRADE_SIZE);
    rd.exportValue(new ValueDescriptor(Values.ASK_VOLUME, "Ask Volume"));
    rd.exportValue(new ValueDescriptor(Values.BID_VOLUME, "Bid Volume"));
    rd.exportValue(new ValueDescriptor(Values.TOTAL_VOLUME, "Classified Volume"));
    rd.exportValue(new ValueDescriptor(Values.DELTA, "Delta"));
    rd.exportValue(new ValueDescriptor(Values.DELTA_PERCENT, "Delta %"));
  }

  @Override
  protected void calculate(int index, DataContext ctx) {
    DataSeries series = ctx.getDataSeries();
    if (index < 0 || index >= series.size()) return;

    long start = series.getStartTime(index);
    long end = series.getEndTime(index);
    if (end <= start) return;

    double minTradeSize = Math.max(0.0,
        getSettings().getDouble(MIN_TRADE_SIZE, 0.0));

    // Array storage is used because values captured by a Java lambda must be
    // final or effectively final.
    final double[] volume = new double[2]; // [0] ask, [1] bid
    Instrument instrument = ctx.getInstrument();

    // Do not generate pseudo-ticks from OHLC bars: useHistoricalBars=false.
    // Subtracting 1 ms keeps a boundary tick from being counted in two bars.
    long queryEnd = Math.max(start, end - 1L);
    instrument.forEachTick(start, queryEnd, ctx.isRTH(), false, tick -> {
      double quantity = tick.getVolumeAsFloat();
      if (quantity <= 0.0 || quantity < minTradeSize) return;

      if (tick.isAskTick()) volume[0] += quantity;
      else volume[1] += quantity;
    });

    double askVolume = volume[0];
    double bidVolume = volume[1];
    double totalVolume = askVolume + bidVolume;

    Color neutral = getSettings().getColor(NEUTRAL_COLOR, DEFAULT_NEUTRAL);
    if (totalVolume <= 0.0) {
      // A neutral bar is an explicit "no classified ticks" result. It is not
      // an estimated zero-delta bar.
      series.setPriceBarColor(index, neutral);
      series.setComplete(index, series.isBarComplete(index));
      return;
    }

    double delta = askVolume - bidVolume;
    double deltaPercent = 100.0 * delta / totalVolume;

    series.setDouble(index, Values.ASK_VOLUME, askVolume);
    series.setDouble(index, Values.BID_VOLUME, bidVolume);
    series.setDouble(index, Values.TOTAL_VOLUME, totalVolume);
    series.setDouble(index, Values.DELTA, delta);
    series.setDouble(index, Values.DELTA_PERCENT, deltaPercent);

    double neutralZone = clamp(
        getSettings().getDouble(NEUTRAL_ZONE, 10.0), 0.0, 50.0);
    double fullIntensity = clamp(
        getSettings().getDouble(FULL_INTENSITY, 60.0), neutralZone + 0.01, 100.0);

    double magnitude = Math.abs(deltaPercent);
    double strength = clamp(
        (magnitude - neutralZone) / (fullIntensity - neutralZone), 0.0, 1.0);

    Color directional = delta >= 0.0
        ? getSettings().getColor(POSITIVE_COLOR, DEFAULT_POSITIVE)
        : getSettings().getColor(NEGATIVE_COLOR, DEFAULT_NEGATIVE);

    series.setPriceBarColor(index, blend(neutral, directional, strength));
    series.setComplete(index, series.isBarComplete(index));
  }

  private static double clamp(double value, double minimum, double maximum) {
    return Math.max(minimum, Math.min(maximum, value));
  }

  private static Color blend(Color from, Color to, double amount) {
    double t = clamp(amount, 0.0, 1.0);
    int red = (int)Math.round(from.getRed() + (to.getRed() - from.getRed()) * t);
    int green = (int)Math.round(from.getGreen() + (to.getGreen() - from.getGreen()) * t);
    int blue = (int)Math.round(from.getBlue() + (to.getBlue() - from.getBlue()) * t);
    int alpha = (int)Math.round(from.getAlpha() + (to.getAlpha() - from.getAlpha()) * t);
    return new Color(red, green, blue, alpha);
  }
}
