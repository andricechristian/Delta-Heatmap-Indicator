ANDRICE DELTA HEATMAP — MOTIVEWAVE
==================================

Purpose
-------
This overlay recolors the chart's normal candles using true bid/ask trade
delta. Bright blue means aggressive buying dominated, bright red means
aggressive selling dominated, and gray means delta was near neutral.

Formula
-------
Ask Volume = sum of trade size for ticks classified at the ask
Bid Volume = sum of trade size for ticks classified at the bid
Delta      = Ask Volume - Bid Volume
Delta %    = 100 * Delta / (Ask Volume + Bid Volume)

The heat intensity is based on the absolute Delta %. The default neutral zone
is 10%, and the color reaches full intensity at 60%.

Important data requirement
--------------------------
This is a true order-flow indicator. It needs trade-by-trade ticks classified
at bid or ask. A CSV containing only Date, Time, Open, High, Low, Close, and
Volume cannot calculate true delta. On an OHLCV-only imported continuous
contract, candles will remain neutral gray.

For ES/NQ, use a native CQG futures instrument/contract with bid/ask historical
tick data enabled. The amount of historical delta visible depends on how much
tick history CQG makes available for that instrument and subscription.

Installation — compiled JAR
---------------------------
1. Close MotiveWave.
2. Copy AndriceDeltaHeatmap.jar into:
     C:\Users\YOUR_NAME\MotiveWave Extensions\lib\
   Create the "lib" folder if it does not exist.
3. Reopen MotiveWave.
4. Open an intraday CQG chart.
5. Choose Studies, then Andrice Indicators, then Andrice Delta Heatmap.

Recommended first test
----------------------
Instrument: a native CQG ES contract (not the imported ES_DB_CONT OHLCV file)
Chart type: time-based candles
Bar size: 1 minute or 5 minutes
Neutral Zone: 10%
Full Color At: 60%
Minimum Trade Size: 0

Interpretation
--------------
Blue candle: more volume traded at the ask than at the bid.
Red candle: more volume traded at the bid than at the ask.
Gray candle: weak/near-zero delta, or no classified tick history was returned.

The candle's market direction and its delta color can disagree. For example,
a rising candle can be red. That is often called delta divergence, but it is
context—not a standalone entry signal.

Source
------
src\com\andrice\motivewave\studies\AndriceDeltaHeatmap.java

Build note
----------
The included JAR was compiled against the official MotiveWave SDK sample
library current at packaging time. If your MotiveWave release rejects the JAR,
send a screenshot of Help > About and the source can be rebuilt for that exact
release.
